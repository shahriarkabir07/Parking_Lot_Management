package parkinglotmanagementsystem;

public class Owner {
    String id, name, phone, vehicleId;

    public Owner(String id, String name, String phone, String vehicleId) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.vehicleId = vehicleId;
    }
}
