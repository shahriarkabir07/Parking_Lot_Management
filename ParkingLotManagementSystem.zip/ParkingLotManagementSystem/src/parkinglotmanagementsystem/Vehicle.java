package parkinglotmanagementsystem;

public class Vehicle {
    String id, plate, ownerId, ownerName, phone, type;
    boolean parked;
    int spot;
    long entryTime;

    public Vehicle(String id, String plate, String ownerId,
                   String ownerName, String phone, String type) {
        this.id        = id;
        this.plate     = plate;
        this.ownerId   = ownerId;
        this.ownerName = ownerName;
        this.phone     = phone;
        this.type      = type;
        this.parked    = false;
        this.spot      = 0;
        this.entryTime = 0;
    }
}
