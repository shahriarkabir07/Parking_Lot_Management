package parkinglotmanagementsystem;

public class Admin {
    String name, phone, email, password;

    public Admin(String name, String phone, String email, String password) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.password = password;
    }
}

