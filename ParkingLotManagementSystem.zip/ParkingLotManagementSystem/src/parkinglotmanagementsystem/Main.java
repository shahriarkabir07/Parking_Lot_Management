package parkinglotmanagementsystem;

public class Main {
    public static void main(String[] args) {
        ParkingService.mainMenu();
    }
}