package parkinglotmanagementsystem;

import java.sql.*;
import java.util.*;

public class ParkingService {

    static Scanner sc = new Scanner(System.in);
    static final int TOTAL_SPOTS = 50;

    // ─────────────────────────────────────────
    // COUNTER HELPER
    // ─────────────────────────────────────────
    static int getNextCounter(Connection con, String prefix,
                              String table, String column) throws Exception {
        PreparedStatement ps = con.prepareStatement(
                "SELECT COUNT(*) FROM " + table + " WHERE " + column + " LIKE ?"
        );
        ps.setString(1, prefix + "%");
        ResultSet rs = ps.executeQuery();
        rs.next();
        return rs.getInt(1) + 1;
    }

    // ─────────────────────────────────────────
    // MAIN MENU
    // ─────────────────────────────────────────
    public static void mainMenu() {
        while (true) {
            System.out.println("\n====== PARKING SYSTEM ======");
            System.out.println("1. Login");
            System.out.println("2. Register Admin");
            System.out.println("3. Exit");
            System.out.print("Choice: ");

            int ch = sc.nextInt();
            sc.nextLine();

            if (ch == 1 && login()) {
                adminMenu();
            } else if (ch == 2) {
                registerAdmin();
            } else if (ch == 3) {
                System.out.println("Goodbye!");
                System.exit(0);
            } else {
                System.out.println("Invalid choice!");
            }
        }
    }

    // ─────────────────────────────────────────
    // ADMIN MENU
    // ─────────────────────────────────────────
    static void adminMenu() {
        while (true) {
            System.out.println("\n===== ADMIN MENU =====");
            System.out.println("1. Add Vehicle");
            System.out.println("2. View Vehicles");
            System.out.println("3. Park Vehicle");
            System.out.println("4. Unpark Vehicle");
            System.out.println("5. Search Vehicle");
            System.out.println("6. Update Vehicle");
            System.out.println("7. Delete Vehicle");
            System.out.println("8. View Parking Map");
            System.out.println("9. Fee Summary");
            System.out.println("10. Exit");

            System.out.print("Choice: ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1 -> addVehicle();
                case 2 -> viewVehicles();
                case 3 -> parkVehicle();
                case 4 -> unparkVehicle();
                case 5 -> searchVehicle();
                case 6 -> updateVehicle();
                case 7 -> deleteVehicle();
                case 8 -> viewAvailableSpots();
                case 9 -> parkingFeeSummary();
                case 10 -> { return; }
                default -> System.out.println("Invalid choice!");
            }
        }
    }

    // ─────────────────────────────────────────
    // ADMIN
    // ─────────────────────────────────────────
    static void registerAdmin() {
        try (Connection con = DBConnection.getConnection()) {
            System.out.print("Name: ");
            String n = sc.nextLine();
            System.out.print("Phone: ");
            String p = sc.nextLine();
            System.out.print("Email: ");
            String e = sc.nextLine();
            System.out.print("Password: ");
            String pass = sc.nextLine();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO admin VALUES (?, ?, ?, ?)"
            );
            ps.setString(1, n);
            ps.setString(2, p);
            ps.setString(3, e);
            ps.setString(4, pass);
            ps.executeUpdate();

            System.out.println("✔ Admin Registered!");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    static boolean login() {
        try (Connection con = DBConnection.getConnection()) {
            System.out.print("Name: ");
            String n = sc.nextLine();
            System.out.print("Password: ");
            String p = sc.nextLine();

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM admin WHERE name=? AND password=?"
            );
            ps.setString(1, n);
            ps.setString(2, p);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("✔ Login Successful!");
                return true;
            }
        } catch (Exception e) {
            System.out.println("Error!");
        }
        return false;
    }

    // ─────────────────────────────────────────
    // ADD VEHICLE
    // ─────────────────────────────────────────
    static void addVehicle() {
        try (Connection con = DBConnection.getConnection()) {

            System.out.print("Plate: ");
            String plate = sc.nextLine();

            PreparedStatement chk = con.prepareStatement(
                    "SELECT id FROM vehicle WHERE plate=?"
            );
            chk.setString(1, plate);
            if (chk.executeQuery().next()) {
                System.out.println("Vehicle already exists!");
                return;
            }

            System.out.print("Owner Name: ");
            String name = sc.nextLine();
            System.out.print("Phone: ");
            String phone = sc.nextLine();
            System.out.print("Type: ");
            String type = sc.nextLine();

            int oc = getNextCounter(con, "OWN", "owner", "id");
            int vc = getNextCounter(con, "VH", "vehicle", "id");

            String ownerId = "OWN" + oc;
            String vehicleId = "VH" + vc;

            PreparedStatement ps1 = con.prepareStatement(
                    "INSERT INTO owner VALUES (?, ?, ?, ?)"
            );
            ps1.setString(1, ownerId);
            ps1.setString(2, name);
            ps1.setString(3, phone);
            ps1.setString(4, vehicleId);
            ps1.executeUpdate();

            PreparedStatement ps2 = con.prepareStatement(
                    "INSERT INTO vehicle VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            ps2.setString(1, vehicleId);
            ps2.setString(2, plate);
            ps2.setString(3, ownerId);
            ps2.setString(4, name);
            ps2.setString(5, phone);
            ps2.setString(6, type);
            ps2.setBoolean(7, false);
            ps2.setInt(8, 0);
            ps2.setLong(9, 0);
            ps2.executeUpdate();

            System.out.println("✔ Vehicle Added!");

        } catch (Exception e) {
            System.out.println("Error!");
        }
    }

    // ─────────────────────────────────────────
    // VIEW VEHICLES
    // ─────────────────────────────────────────
    static void viewVehicles() {
        try (Connection con = DBConnection.getConnection()) {
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM vehicle");

            while (rs.next()) {
                System.out.println(
                        rs.getString("id") + " | "
                                + rs.getString("plate") + " | "
                                + rs.getString("ownerName") + " | "
                                + (rs.getBoolean("parked") ? "Parked" : "Free")
                                + " | Spot: " + rs.getInt("spot")
                );
            }
        } catch (Exception e) {
            System.out.println("Error!");
        }
    }

    // ─────────────────────────────────────────
    // PARK VEHICLE
    // ─────────────────────────────────────────
    static void parkVehicle() {
        try (Connection con = DBConnection.getConnection()) {

            System.out.print("Enter Vehicle ID or Plate: ");
            String input = sc.nextLine();

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM vehicle WHERE id=? OR plate=?"
            );
            ps.setString(1, input);
            ps.setString(2, input);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                System.out.println("Vehicle not found!");
                return;
            }

            if (rs.getBoolean("parked")) {
                System.out.println("Already parked!");
                return;
            }

            int spot = findAvailableSpot(con);
            if (spot == -1) {
                System.out.println("Parking FULL!");
                return;
            }

            long entryTime = System.currentTimeMillis();

            PreparedStatement upd = con.prepareStatement(
                    "UPDATE vehicle SET parked=true, spot=?, entryTime=? WHERE id=?"
            );
            upd.setInt(1, spot);
            upd.setLong(2, entryTime);
            upd.setString(3, rs.getString("id"));
            upd.executeUpdate();

            System.out.println("✔ Parked at Spot: " + spot);

        } catch (Exception e) {
            System.out.println("Error!");
        }
    }

    // ─────────────────────────────────────────
    // UNPARK VEHICLE
    // ─────────────────────────────────────────
    static void unparkVehicle() {
        try (Connection con = DBConnection.getConnection()) {

            System.out.print("Enter Vehicle ID or Plate: ");
            String input = sc.nextLine();

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM vehicle WHERE id=? OR plate=?"
            );
            ps.setString(1, input);
            ps.setString(2, input);
            ResultSet rs = ps.executeQuery();

            if (!rs.next() || !rs.getBoolean("parked")) {
                System.out.println("Vehicle not parked!");
                return;
            }

            long entry = rs.getLong("entryTime");
            long exit = System.currentTimeMillis();

            double hours = (exit - entry) / 3600000.0;
            double fee = calculateFee(rs.getString("type"), hours);

            PreparedStatement upd = con.prepareStatement(
                    "UPDATE vehicle SET parked=false, spot=0, entryTime=0 WHERE id=?"
            );
            upd.setString(1, rs.getString("id"));
            upd.executeUpdate();

            System.out.println("✔ Unparked | Fee: " + fee + " BDT");

        } catch (Exception e) {
            System.out.println("Error!");
        }
    }

//Search for vehicle
static void searchVehicle() {
    try (Connection con = DBConnection.getConnection()) {
        System.out.print("Enter Vehicle ID or Plate: ");
        String input = sc.nextLine();

        PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM vehicle WHERE id=? OR plate=?"
        );
        ps.setString(1, input);
        ps.setString(2, input);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            System.out.println("\n===== VEHICLE FOUND =====");
            System.out.println("ID      : " + rs.getString("id"));
            System.out.println("Plate   : " + rs.getString("plate"));
            System.out.println("Owner   : " + rs.getString("ownerName"));
            System.out.println("Phone   : " + rs.getString("phone"));
            System.out.println("Type    : " + rs.getString("type"));
            System.out.println("Status  : " + (rs.getBoolean("parked") ? "Parked" : "Free"));
            System.out.println("Spot    : " + rs.getInt("spot"));
        } else {
            System.out.println("Vehicle not found!");
        }

    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}

//Update Vehicle
static void updateVehicle() {
    try (Connection con = DBConnection.getConnection()) {
        System.out.print("Enter Vehicle ID: ");
        String id = sc.nextLine();

        PreparedStatement check = con.prepareStatement(
                "SELECT * FROM vehicle WHERE id=?"
        );
        check.setString(1, id);
        ResultSet rs = check.executeQuery();

        if (!rs.next()) {
            System.out.println("Vehicle not found!");
            return;
        }

        System.out.print("New Owner Name: ");
        String name = sc.nextLine();
        System.out.print("New Phone: ");
        String phone = sc.nextLine();
        System.out.print("New Type: ");
        String type = sc.nextLine();

        PreparedStatement ps = con.prepareStatement(
                "UPDATE vehicle SET ownerName=?, phone=?, type=? WHERE id=?"
        );
        ps.setString(1, name);
        ps.setString(2, phone);
        ps.setString(3, type);
        ps.setString(4, id);

        ps.executeUpdate();

        System.out.println("✔ Vehicle Updated!");

    } catch (Exception e) {
        System.out.println("Error!");
    }
}

//Delete vehicle
static void deleteVehicle() {
    try (Connection con = DBConnection.getConnection()) {
        System.out.print("Enter Vehicle ID: ");
        String id = sc.nextLine();

        PreparedStatement check = con.prepareStatement(
                "SELECT * FROM vehicle WHERE id=?"
        );
        check.setString(1, id);
        ResultSet rs = check.executeQuery();

        if (!rs.next()) {
            System.out.println("Vehicle not found!");
            return;
        }

        PreparedStatement ps = con.prepareStatement(
                "DELETE FROM vehicle WHERE id=?"
        );
        ps.setString(1, id);
        ps.executeUpdate();

        System.out.println("✔ Vehicle Deleted!");

    } catch (Exception e) {
        System.out.println("Error!");
    }
}

//View Parking Spots
static void viewAvailableSpots() {
    try (Connection con = DBConnection.getConnection()) {

        ResultSet rs = con.createStatement().executeQuery(
                "SELECT spot FROM vehicle WHERE parked=true"
        );

        Set<Integer> occupied = new HashSet<>();

        while (rs.next()) {
            occupied.add(rs.getInt("spot"));
        }

        System.out.println("\n===== PARKING MAP =====");

        for (int i = 1; i <= TOTAL_SPOTS; i++) {
            if (occupied.contains(i)) {
                System.out.print("[XX] ");
            } else {
                System.out.print("[  ] ");
            }

            if (i % 10 == 0) System.out.println();
        }

        System.out.println("\n[XX] = Occupied   [ ] = Free");
        System.out.println("Available Spots: " + (TOTAL_SPOTS - occupied.size()));

    } catch (Exception e) {
        System.out.println("Error!");
    }
}

//Parking Fee Calculation
static void parkingFeeSummary() {
    try (Connection con = DBConnection.getConnection()) {

        ResultSet rs = con.createStatement().executeQuery(
                "SELECT type, COUNT(*) as total FROM vehicle GROUP BY type"
        );

        System.out.println("\n===== VEHICLE SUMMARY =====");

        while (rs.next()) {
            System.out.println(
                    rs.getString("type") + " : " + rs.getInt("total")
            );
        }

    } catch (Exception e) {
        System.out.println("Error!");
    }
}


    // ─────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────
    static int findAvailableSpot(Connection con) throws Exception {
        ResultSet rs = con.createStatement().executeQuery(
                "SELECT spot FROM vehicle WHERE parked=true"
        );

        Set<Integer> used = new HashSet<>();
        while (rs.next()) {
            used.add(rs.getInt("spot"));
        }

        for (int i = 1; i <= TOTAL_SPOTS; i++) {
            if (!used.contains(i)) return i;
        }
        return -1;
    }

    static double calculateFee(String type, double hrs) {
        double rate = switch (type.toLowerCase()) {
            case "bike" -> 20;
            case "truck" -> 100;
            default -> 50;
        };
        return rate * Math.max(1, Math.ceil(hrs));
    }
}
